package NumberGuessingGame;

import java.util.Random;
import java.util.Scanner;

public class NumberGuessingGame {
    
    private static final int MAX_ATTEMPTS = 7;
    private static final int MAX_ROUNDS = 5;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();
        int totalScore = 0;
        int roundsPlayed = 0;

        while (roundsPlayed < MAX_ROUNDS) {
            System.out.println("\n--- Round " + (roundsPlayed + 1) + " ---");
            int numberToGuess = random.nextInt(100) + 1;
            int attempts = 0;
            boolean guessedCorrectly = false;

            System.out.println("Guess the number between 1 and 100. You have " + MAX_ATTEMPTS + " attempts.");

            while (attempts < MAX_ATTEMPTS) {
                System.out.print("Attempt " + (attempts + 1) + ": Enter your guess: ");
                int guess = scanner.nextInt();
                attempts++;

                if (guess < numberToGuess) {
                    System.out.println("Too low!");
                } else if (guess > numberToGuess) {
                    System.out.println("Too high!");
                } else {
                    System.out.println("Congratulations! You guessed the number " + numberToGuess + " correctly.");
                    guessedCorrectly = true;
                    break;
                }
            }

            if (!guessedCorrectly) {
                System.out.println("Sorry, you've used all your attempts. The number was " + numberToGuess + ".");
            }

            int score = guessedCorrectly ? Math.max(0, (MAX_ATTEMPTS - attempts + 1)) : 0;
            System.out.println("Score for this round: " + score);
            totalScore += score;

            roundsPlayed++;
            
            if (roundsPlayed < MAX_ROUNDS) {
                System.out.print("Do you want to play another round? (yes/no): ");
                String playAgain = scanner.next().trim().toLowerCase();
                if (!playAgain.equals("yes")) {
                    break;
                }
            }
        }

        System.out.println("\nGame Over! You played " + roundsPlayed + " rounds.");
        System.out.println("Your total score is: " + totalScore);
        scanner.close();
    }
}
